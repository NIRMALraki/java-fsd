package logestIS;

import java.util.Scanner;

public class Lis {
	static int cal(int arr[], int n)
    {
        int lis[] = new int[n];
        int a, b, m = 0;
 
      
        for (a = 0; a < n; a++)
        {
            lis[a] = 1;
        }
        
//        for (int i = 0; i < lis.length; i++) {
//			System.out.print(lis[i]+",");
//			
//		}
 
    
        for (a = 1; a < n; a++)
        {
            for (b = 0; b < a; b++)
            {
                if (arr[a] > arr[b] && lis[a] < lis[b] + 1)
                    lis[a] = lis[b] + 1;
                //System.out.println("if"+lis[a]);
            }
        }
 
       
        for (a = 0; a < n; a++)
        {
            if (m < lis[a])
                m = lis[a];
        }
 
        return m;
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int len=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the length of array");
		len=sc.nextInt();
		 int arr[] = new int[len];
		 for (int i = 0; i < len; i++) {
			 System.out.println("enter the "+i+"th number" );
			arr[i] = sc.nextInt();
			
		}
	     System.out.println("LIS is "+cal(arr, arr.length));
		

	}

}
