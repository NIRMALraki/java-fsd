package Assisted_project;

public class Constructors {
	
	int a;
	float b;
	String st;
	
	void values() 
	{
		System.out.println("a :"+a+"\nb :"+b+"\nc :"+st);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Constructors con = new Constructors();
		
		con.values();
		
		Constructors1 c1 = new Constructors1(10,84.54f,"nirmal");
		c1.values();
	}

}
class Constructors1
{
	int a;
	float b;
	String st;
	Constructors1(int a, float b,String st)
	{
		this.a=a;
		this.b=b;
		this.st=st;
	}
	
	void values() 
	{
		System.out.println("a :"+a+"\nb :"+b+"\nc :"+st);
	}
}
