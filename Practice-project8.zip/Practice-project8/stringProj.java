package Assisted_project;

public class stringProj {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			String st1 = new String("Assisted project");
			
			System.out.println(st1.charAt(5));
			
			System.out.println(st1.lastIndexOf("Assisted"));
			
			System.out.println(st1.indexOf('s'));
			
			System.out.println(st1.substring(10));
			
			System.out.println(st1.compareTo("non assisted project"));
			
			System.out.println(st1.toUpperCase());
			
			System.out.println(st1.contentEquals("project"));
			
			System.out.println("**** Stringbuffer conversion ****");
			
			StringBuffer sb = new StringBuffer(st1);
			
			sb.append("String");
			
			sb.reverse();
			System.out.println(sb);
			
			System.out.println("**** Stringbuilder conversion ***** ");
			StringBuilder sbu = new StringBuilder(st1);
			
			sbu.insert(7, 'u');
			System.out.println(sbu);
			
			System.out.println(sbu.delete(8, 9));
			
			sbu.insert( sbu.length()," is completed");
			System.out.println(sbu);
			
			
	}

}
