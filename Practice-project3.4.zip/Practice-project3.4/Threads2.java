package Assisted_project;

public class Threads2 implements Runnable{
	 static int num=0;
	@Override
	public void run() {
		
		while(Threads2.num<=10)
		{
		System.out.println("from run method  "+ ++Threads2.num);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			Threads2 t2= new Threads2();
			Thread t = new Thread(t2);
			t.start();
			
			while(Threads2.num<=10)
			{
				System.out.println("from main method " + ++Threads2.num);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			

	}

	

}
