package assistedphase3;

import java.util.Arrays;
import java.util.List;

public class FourthSmallest {
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 int arr[] = { 12, 3, 5, 7, 19 };
	        int k = 4;
	       // List<int[]> l = Arrays.asList(arr);
	        Arrays.sort(arr);
	        System.out.print("4'th smallest element is " + arr[k-1]);
	}

}
