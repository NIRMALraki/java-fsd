package assstedPhase4;

import java.util.Arrays;

public class BinarySearches {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {5,6,3,7,43,3,45,7,6};
		int key=43;
		int index;
		
		if((index=Arrays.binarySearch(arr, key))!=-1)
		{
			System.out.println("the index of the element is "+index);
		}
		else
		{
			System.out.println("not found");
		}

	}

}
