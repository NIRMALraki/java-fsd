package assstedPhase4;

import java.util.Arrays;

public class Exponential {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {5,6,3,7,43,3,45,7,6};
		int key=43;
		int index;
		Arrays.sort(arr);
		if(key==arr[0])
		{
			System.out.println("the index is 0");
	
		}
		else 
		{
			 int i = 1;
		        while (i < arr.length && arr[i] <= key)
		        {
		            i = i*2;
		            
		        }
		        
		        if((index=Arrays.binarySearch(arr, i/2, Math.min(i,arr.length-1), key))!=-1)
		        {
		        	System.out.println("array index : "+index);
		        	
		        }
		        else
		        {
		        	System.out.println("not found");
		        }
		        
		        for (int j = 0; j < arr.length; j++) {
					
	        		System.out.print(arr[j]+" , ");
				}
		}

	}

}
