package Assisted_project;
interface Address{
	void address(String address);
}

interface Driver
{
	void details(String details);
}

class Student implements Address,Driver
{

	@Override
	public void address(String Address) {
		// TODO Auto-generated method stub
		System.out.println(Address);
		
	}

	@Override
	public void details(String details) {
		// TODO Auto-generated method stub
		System.out.println(details);
	}
}

	

public class Diamond  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student student1 = new Student();
		student1.address("peenya");
		student1.details("route1");
		
		Student student2 = new Student();
		student2.address("mg road");
		student2.details("route7");
	

	}

}
