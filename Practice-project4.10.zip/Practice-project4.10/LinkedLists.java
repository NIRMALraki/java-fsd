package assistedphase3;

public class LinkedLists {
	
	Node head; 
	static class Node 
	{ 
    		int data; 
    		Node next; 
    		Node(int d) 
    		{ 
        			data = d; 
        			next = null; 
    		} 
	} 
 
	public static LinkedLists insert(LinkedLists l, int d) 
	{ 
    		 
    		Node newNode = new Node(d); 
    		newNode.next = null; 
		
    		if (l.head == null) 
    		{ 
        			l.head = newNode; 
    		} 
    		else 
    		{ 
        			
        			Node la = l.head; 
        			while (la.next != null) 
        			{ 
            			la = la.next; 
        			} 
			
        			la.next = newNode; 
    		} 
    		return l; 
	} 
	public static void printList(LinkedLists l) 
		{	 
    		Node currentNode = l.head; 
    		System.out.print("LinkedList: "); 
    		
    		while (currentNode != null) 
    		{ 
        			
        			System.out.print(currentNode.data + " "); 
        			
        			currentNode = currentNode.next; 
    		} 
    		System.out.println(); 
		} 
	
	public static LinkedLists deleteByKey(LinkedLists l, int k) 
		{ 
    		
    		Node currentNode = l.head, prev = null; 
    		if(currentNode != null && currentNode.data == k) 
    		{ 
        			l.head = currentNode.next; 
        			System.out.println(k + " is found and deleted"); 
        			return l; 
    		} 
    		while (currentNode != null && currentNode.data != k) 
    		{ 
        			prev = currentNode; 
        			currentNode = currentNode.next; 
    		} 
    		if (currentNode != null) 
    		{ 
        			prev.next = currentNode.next; 
        			System.out.println(k + " is found and deleted"); 
    		} 
    		if (currentNode == null) 
    		{ 
        			System.out.println(k + " not exist"); 
    		} 
    		return l; 
	} 


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedLists li = new LinkedLists(); 
	 
		li = insert(li, 1); 
		li = insert(li, 45); 
		li = insert(li, 65); 
		li = insert(li, 56); 
		li = insert(li, 21); 
		li = insert(li, 76); 
		li = insert(li, 87); 
		li = insert(li, 98); 
	 
		printList(li); 
		deleteByKey(li, 45); 
		printList(li); 
		

	}

}
