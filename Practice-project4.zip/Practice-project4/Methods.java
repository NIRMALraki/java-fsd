package Assisted_project;

public class Methods {
	
	void sample_method()
	{
		System.out.println("Inside sample method");
	}
	
	int byvalue(int a)
	{
		return a;
	}
	
	void login(String name,String email)
	{
		System.out.println("name : "+name);
		System.out.println("email : "+email);
	}
	
	void login(String name,String email,int phono)
	{
		System.out.println("name :"+name);
		System.out.println("email :"+email);
		System.out.println("phno :"+phono);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				
		Methods a1 = new Methods();
		a1.sample_method();
		
		System.out.println(a1.byvalue(56));
		
		a1.login("nirmal", "nirmal@gmial.com");
		a1.login("nirmal", "nirmal@gmial.com",911060208);
		
		
	}

}
