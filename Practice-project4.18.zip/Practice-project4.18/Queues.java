package assistedphase3;

import java.util.*;

public class Queues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Queue<String> q= new LinkedList<>();
		q.add("first");
		q.add("second");
		q.add("third");
		q.add("fourth");
		
		for (String string : q) {
			System.out.println(string);
		}

		System.out.println("peak "+q.peek());
		q.remove();
		System.out.println(q.toString());
	
		
		
	}

}
