package com.dao;






import javax.persistence.TypedQuery;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.bean.*;

@Repository
public class Userdao {
	
	@Autowired
	User u ;
	
	@Autowired
	SessionFactory sf;
	
	public User getUser(String email)
	{
		Session s=sf.openSession();
		
		u =s.get(User.class, email);
		s.close();
		return u;
		
	}
	
	public int updateUser(User uu)
	{
		try {
			Session s= sf.openSession();
			Transaction t= s.beginTransaction();
//			u.setId(uu.getId());
//			u.setName(uu.getName());
//			u.setAddress(uu.getAddress());
			s.update(uu);
			//TypedQuery<User> query2 = s.createQuery("Update User u set u.emailid=? where u=?");
			t.commit();
			return 0;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 1;
		}
	}
}
