package com.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="user")
public class User {

	@Id
	private String emailid;
	private String name;
	private String address;
	public String getId() {
		return emailid;
	}
	public void setId(String id) {
		this.emailid = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "User [id=" + emailid + ", Name=" + name + ", address=" + address + "]";
	}
	
	
}
