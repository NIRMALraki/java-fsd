package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.User;
import com.dao.Userdao;

@Service
public class UserService {

	@Autowired
	Userdao dao;
	@Autowired
	User u;
	
	public User getUser(String email)
	{
		u=dao.getUser(email);
		
			return u;
		
	
	}
	
	public String Update(User u)
	{
		if(dao.updateUser(u)<1)
		{
			return "Updated";
		}
		else
		{
			return "failed to update";
		}
		
	
		
	
	}
}
