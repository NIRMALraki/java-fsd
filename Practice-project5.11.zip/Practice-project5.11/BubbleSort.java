package assstedPhase4;

public class BubbleSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {5,6,3,7,43,3,45,7,6};
		int temp;
		
		for (int i= 0;  i< arr.length; i++) {
			
			for (int j = 1; j < arr.length; j++) {
				
				if(arr[j-1] > arr[j]){  
					{
						 
	                    temp = arr[j-1];  
	                    arr[j-1] = arr[j];  
	                    arr[j] = temp;
					}
				}
                    
			}
		}
		
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+" , ");
		}

	}

}
