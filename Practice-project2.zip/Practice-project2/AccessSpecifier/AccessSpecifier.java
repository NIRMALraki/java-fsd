package AccessSpecifier;

public class AccessSpecifier {
	public int a=5;
	int b=10;
	protected String c="Protected";
			public void method1()
			{
				System.out.println("Public method from AccessSpecifier class");
			}
			
		private void method2()
		{
			System.out.println("this is a private method");
		}
		
		
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
			AccessSpecifier ap= new AccessSpecifier();
			//trying to access the private method in same class it works
			ap.method2();

	}

}

 