package AccessSpecifier;

public class Class2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			AccessSpecifier ac= new AccessSpecifier();
			
			System.out.println("accessing default from same pakage" +ac.b);
			System.out.println("accessing protected data member"+ac.c);
			// Trying to access private method but it will throw an error
			//ac.method2();
			
	}	

}
