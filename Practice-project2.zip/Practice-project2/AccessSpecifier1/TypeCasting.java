package Assisted_project;

import java.util.Scanner;

public class TypeCasting {

	public static void main(String[] args) {
		//implicit
		int integer= 10;
		System.out.println("Int "+integer);
		double dou=integer;
		System.out.println("Int to Double : "+dou);
		float flo = integer;
		System.out.println("Int to float : "+flo);
		long lon= integer;
		System.out.println("Int to Long : "+lon);
		double doulb= flo;
		System.out.println("Float to Double : "+doulb);
		//explicit
		System.out.println("Explicit............");
		 long lo= (long) flo;
		 System.out.println("float to long: "+lo);
		 float f1= (float) dou;
		 System.out.println("double to float : "+f1);
		 int i1= (int)f1;
		 System.out.println("float to int : "+i1);

	}

}
