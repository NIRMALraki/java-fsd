package AccessSpecifier1;

import AccessSpecifier.AccessSpecifier;

public class AccessSpecifier1 extends AccessSpecifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccessSpecifier as= new AccessSpecifier();
		as.method1();
		//trying to access default data member from different package
		//as.b;
		AccessSpecifier1 ac1= new AccessSpecifier1();
		System.out.println("Accessing protected data member by extending ::  "+ac1.c);
		
		
	}

}
