package session;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SessionDashboard
 */
public class SessionDashboard extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SessionDashboard() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession s = request.getSession(false);
		PrintWriter pw= response.getWriter();
		String user=null;
		if(s.getAttribute("user")==null)
		{
			pw.println("session not found");
			
		}
		else
		{
			pw.println("session found "+user);
			 user=(String) s.getAttribute("user");
		}
//		if(s.getAttribute("user")!=null)
//		{
//		
//			
//		}
		
	
		
		
		
		
	}

}
