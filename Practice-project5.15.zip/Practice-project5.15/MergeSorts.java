package assstedPhase4;

public class MergeSorts {
	static void merge(int arr[], int f, int m, int l)    
	{    
	    int i, j, k;  
	    int n1 = m - f + 1;    
	    int n2 = l - m;    
	      
	   
	        int leftarr[] = new int[n1];  
	        int rightarr[] = new int[n2];  
	      
	    for (i = 0; i < n1; i++) 
	    {
	    leftarr[i] = arr[f + i];    
	    }
	    for (j = 0; j < n2; j++)   
	    {
	    rightarr[j] = arr[m + 1 + j];   
	    }
	      
	    i = 0; j = 0;  k = f; 
	      
	    while (i < n1 && j < n2)    
	    {    
	        if(leftarr[i] <= rightarr[j])    
	        {    
	            arr[k] = leftarr[i];    
	            i++;    
	        }    
	        else    
	        {    
	            arr[k] = rightarr[j];    
	            j++;    
	        }    
	        k++;    
	    }    
	    while (i<n1)    
	    {    
	        arr[k] = leftarr[i];    
	        i=i+1; k=k+1;    
	    }    
	      
	    while (j<n2)    
	    {    
	        arr[k] = rightarr[j];    
	        i=i+1; k=k+1;    
	    }    
	}    
	  
	static void mS(int arr[], int f, int l)  
	{  
	    if (f < l)   
	    {  
	        int mid = (f + l) / 2;  
	        mS(arr, f, mid);  
	        mS(arr, mid + 1, l);  
	        merge(arr, f, mid, l);  
	    }  
	}  
	  
	public static void main(String[] args) {
		
		int arr[] = {5,6,3,7,43,3};
		mS(arr, 0, arr.length-1);
		
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+" , ");
		}
		
	}

}
