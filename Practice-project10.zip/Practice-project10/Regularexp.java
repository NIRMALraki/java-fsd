package Assisted_project;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regularexp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("*****password validation*****");
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the password of length greater than 8");
		String pas= sc.nextLine();
		String exp="^[\d|\s]{8,}$";
		Pattern pat = Pattern.compile(exp);
		Matcher m  = pat.matcher(pas);
		if(m.matches())
		{
			System.out.println("validation successfull");
		}
		else
		{
			System.out.println("failed");
		}
		

	}

}
