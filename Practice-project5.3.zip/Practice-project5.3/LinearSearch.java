package assstedPhase4;

public class LinearSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {5,6,3,7,43,3,45,7,6};
		int key=43;
		
		for (int i = 0; i < arr.length; i++) {
			if(key==arr[i])
			{
				System.out.println(arr[i]+" found in array and the index is: "+i);
			}
			
		}

	}

}
