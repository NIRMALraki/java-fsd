package Assisted_project;

public class Innerclass1 {
	
	void innerclassmethod() {
		class internal
		{
			void method1(){
				System.out.println("inside method");
			}
		}
		internal in = new internal();
		in.method1();
	}
	
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Innerclass1 ins= new Innerclass1();
		ins.innerclassmethod();
		Innerclass1.inside in =ins.new inside();
		in.method1();
		abst abs1= new abst() {
			@Override
			public void m1() {
				
				System.out.println("anonymous class implementation");
			}
			
		};
		abs1.m1();
	}

	class inside{ 
			void method1()
			{
				System.out.println(" inside class");
			}
	}
	
}
abstract class abst{
	public abstract void m1();
}


