package com.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bean.Clas;
import com.bean.Subject;
import com.bean.Trainer;

public class Trainerdao {

public Session connection()
	
	{
		 Configuration con = new Configuration();
         con.configure("hibernate.cfg.xml");
         SessionFactory sf = con.buildSessionFactory();
         Session session = sf.openSession();
         return session;
	}

	public int storeTrainer(Trainer t) {
        try {
        	Session session= connection();

            Transaction tran = session.getTransaction();
            tran.begin();
                    session.save(t);
            tran.commit();
            return 1;
        } catch (Exception e) {
            System.out.println(e);
            return 0;
        }
    }
	
	 public List<Trainer> findAllTrainer() {
		 Session session= connection();
         //Transaction tran = session.getTransaction();
         TypedQuery<Trainer> qry = session.createQuery("select t from Trainer t");
         List<Trainer> listOfTrainer = qry.getResultList();
         return listOfTrainer;
 }
	 public int assign(int sid,int tid)
		{
			Session session= connection();
			 try {
				Subject s=session.get(Subject.class, sid);
				Trainer t = session.get(Trainer.class, tid);
				for (Subject subject : t.getListofsub()) {
					System.out.println(subject.getId()+"==== before adding  "+subject.getName());
					
				}
				t.getListofsub().add(s);
				s.setTr(t);
				//System.out.println(s.toString());
				for (Subject subject : t.getListofsub()) {
					System.out.println(subject.getId()+"  after adding "+subject.getName());
					
				}
		            Transaction tran = session.getTransaction();
		            tran.begin();
				 session.update(t);
				 session.update(s);
				 tran.commit();
			session.close();
				 return 1;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return 0;
			}
		
		}
}
