package com.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.eclipse.jdt.internal.compiler.batch.Main;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bean.Clas;
import com.bean.Student;
import com.bean.Subject;

public class Subjectdao {
	
	
	public Session connection()
	
	{
		 Configuration con = new Configuration();
         con.configure("hibernate.cfg.xml");
         SessionFactory sf = con.buildSessionFactory();
         Session session = sf.openSession();
         return session;
	}
	
	public int storeSubject(Subject sub)
	{
		try {
			
			Session session= connection();
            Transaction tran = session.getTransaction();
            tran.begin();
                    session.save(sub);
            tran.commit();
            return 1;
        } catch (Exception e) {
            System.out.println(e);
            return 0;
        }
	}
	
	public List<Subject> findAllSubject()
	{
		Session session= connection();
		 TypedQuery<Subject> qry = session.createQuery("select s from Subject s");
	        List<Subject> listOfSubject = qry.getResultList();
	        return listOfSubject;
		
	}
	public int assign(int sid,int cid)
	{
		Session session= connection();
		 //TypedQuery<Subject> qry = session.createQuery("select s from Subject s");
		 try {
			Subject s=session.get(Subject.class, sid);
			Clas c = session.get(Clas.class, cid);
			for (Subject subject : c.getListofsub()) {
				System.out.println(subject.getId()+"==== before adding  "+subject.getName());
				
			}
			c.getListofsub().add(s);
			s.setCs(c);
			//System.out.println(s.toString());
			for (Subject subject : c.getListofsub()) {
				System.out.println(subject.getId()+"  after adding "+subject.getName());
				
			}
	            Transaction tran = session.getTransaction();
	            tran.begin();
			 session.update(c);
			 session.update(s);
			 tran.commit();
		session.close();
			 return 1;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	
	}
	public static void main(String[] args) {
		Subjectdao dao = new Subjectdao();
		//int a=dao.assign(1,2);
		//System.out.println(a);
		Session session = dao.connection();
		//Subject s=session.get(Subject.class, sid);
		
		Transaction ts = session.beginTransaction();
		Clas c = session.get(Clas.class, 6);
		ts.commit();
//		System.out.println(c);
//		List<Subject> sb=c.getListofsub();
//		for (Subject subject : sb) {
//			System.out.println(subject);	
//			
//		}
		
//		Clas c= new Clas();
//		Subject s = new Subject();
//		c.setClassid(6);
//		c.setClassname("b5");
//		s.setId(6);
//		s.setName(".net");
//		s.setCs(c);
//		c.getListofsub().add(s);
		
//		Transaction ts = session.beginTransaction();
//		session.save(c);
//		session.save(s);
//		ts.commit();
		
		for (Subject st : c.getListofsub()) {
			System.out.println(st.getName());
		}
		
		
		
	}

}
