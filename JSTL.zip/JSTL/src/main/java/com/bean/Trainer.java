package com.bean;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
@Entity
public class Trainer {
	@Id 
	private int id;
	private String name;
	@OneToMany(cascade = CascadeType.ALL,mappedBy = "tr")
	private List<Subject> listofsub;
	@ManyToOne
	@JoinColumn(name="classid")
	private Clas cs;
	//private Integer ctr_id; //class trainer id
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Subject> getListofsub() {
		return listofsub;
	}
	public void setListofsub(List<Subject> listofsub) {
		this.listofsub = listofsub;
	}
	public Clas getCs() {
		return cs;
	}
	public void setCs(Clas cs) {
		this.cs = cs;
	}
	@Override
	public String toString() {
		return "Trainer [id=" + id + ", name=" + name + ", listofsub=" + listofsub + ", cs=" + cs + "]";
	}
	
	
	
	
	
	

}
