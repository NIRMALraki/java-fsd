package com.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Student {
	@Id
	private int sid;
	private String sname;
	private int age;
	@ManyToOne
	@JoinColumn(name="classid")
	private Clas cs;
	//private Integer cst_id; //class student
		
	public int getSid() {
		return sid;
	}
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", age=" + age + ", cs=" + cs + "]";
	}
	public Clas getCs() {
		return cs;
	}
	public void setCs(Clas cs) {
		this.cs = cs;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

	
	
	
	

}
