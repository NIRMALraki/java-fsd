package com.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Subject {
	@Id
	private int sid;
	private String name;
	@ManyToOne
	@JoinColumn(name="classid")
	private Clas  cs;
	@ManyToOne
	@JoinColumn(name="id")
	private Trainer tr;
	
	public Trainer getTr() {
		return tr;
	}
	public void setTr(Trainer tr) {
		this.tr = tr;
	}
	public Clas getCs() {
		return cs;
	}
	public void setCs(Clas cs) {
		this.cs = cs;
	}
	//private Integer csu_id;  //class subject id
	//private Integer tsu_id;	// trainer subject id
	
	
	public int getId() {
		return sid;
	}
	public void setId(int id) {
		this.sid = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
@Override
	public String toString() {
		return "Subject [id=" + sid + ", name=" + name + ", cs=" + cs + ", tr=" + tr + "]";
	}
	
	
	

}
