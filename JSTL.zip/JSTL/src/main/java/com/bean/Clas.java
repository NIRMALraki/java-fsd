package com.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="class")
public class Clas {
	@Id
	private int classid;
	private String classname;
	@OneToMany(cascade = {CascadeType.ALL},mappedBy ="cs")
	private List<Student> listofstu= new ArrayList<>();
	@OneToMany(cascade = { CascadeType.ALL},mappedBy ="cs")
	private List<Subject> listofsub=new ArrayList<>();; 
	@OneToMany(cascade = {CascadeType.ALL},mappedBy = "cs")
	private List<Trainer> listoftra=new ArrayList<>();;
	
	
	public int getClassid() {
		return classid;
	}
	public void setClassid(int classid) {
		this.classid = classid;
	}
	public String getClassname() {
		return classname;
	}
	public void setClassname(String classname) {
		this.classname = classname;
	}
	public List<Student> getListofstu() {
		return listofstu;
	}
	public void setListofstu(List<Student> listofstu) {
		this.listofstu = listofstu;
	}
	public List<Subject> getListofsub() {
		return listofsub;
	}
	public void setListofsub(List<Subject> listofsub) {
		this.listofsub = listofsub;
	}
	public List<Trainer> getListoftra() {
		return listoftra;
	}
	public void setListoftra(List<Trainer> listoftra) {
		this.listoftra = listoftra;
	}
	@Override
	public String toString() {
		return "Clas [classid=" + classid + ", classname=" + classname + ", listofstu=" + listofstu + ", listofsub="
				+ listofsub + ", listoftra=" + listoftra + "]";
	}
	
	

}
