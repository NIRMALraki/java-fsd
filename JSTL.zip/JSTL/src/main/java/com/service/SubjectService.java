package com.service;

import java.util.List;

import com.bean.Subject;
import com.dao.Subjectdao;

public class SubjectService {
	
	Subjectdao dao = new Subjectdao();
	
	
	public String storeSubject(Subject s)
	{
			if(dao.storeSubject(s)>0)
			{
				return "Subject details stored Successfully";
			}
			else
			{
				return "could not store Subject details ";
			}
	}
	
	public List<Subject> findAllSubject()
	{
		return dao.findAllSubject();
	}
	
	
	public String assignSubjectToClass(int sid,int cid)
	 {
		 if(dao.assign(sid, cid)>0) {
	            return "Assigned Successfully";
	        }else {
	            return "Failed to assign";
	        }
		 
		 
	 }
	
	public String assignSubject(int sid ,int cid)
	{
			if(dao.assign(sid, cid)>0)
			{
				return "Subject Assigned to class Successfully";
			}
			else
			{
				return "could not Assign. Failed! ";
			}
	}
	
}
