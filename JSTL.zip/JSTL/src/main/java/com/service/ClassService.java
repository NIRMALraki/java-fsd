package com.service;

import java.util.List;

import com.bean.*;
import com.dao.*;

public class ClassService {
	
Classdao dao = new Classdao();
	
	
	public String storeClass(Clas s)
	{
			if(dao.storeClass(s)>0)
			{
				return "Class details stored Successfully";
			}
			else
			{
				return "could not store Class details ";
			}
	}
	
	public List<Clas> findAllClass()
	{
		return dao.findAllClass();
	}

}
