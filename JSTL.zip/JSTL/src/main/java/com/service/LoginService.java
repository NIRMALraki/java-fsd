package com.service;

import com.bean.Login;

public class LoginService {
	
	public int login(Login l)
	{
		if(l.getEmail().equals("nirmal@gmail.com")&&l.getPassword().equals("nirmal"))
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}

}
