package com.service;

import java.util.List;


import com.bean.Trainer;
import com.dao.Trainerdao;

public class TrainerService {
	
	Trainerdao dao = new Trainerdao();
	
	
	 public String storeTrainer(Trainer trainer) {
	        if(dao.storeTrainer(trainer)>0) {
	            return "Trainer details stored successfully";
	        }else {
	            return "could not store Trainer details";
	        }
	    }
	 
	 public List<Trainer> findAllTrainer() {
	 
		 return dao.findAllTrainer();
	 }
	 
	 public String assignSubject(int sid ,int tid)
		{
				if(dao.assign(sid, tid)>0)
				{
					return "Assigned ";
				}
				else
				{
					return "could not Assign. Failed! ";
				}
		}
}
