package com.service;

import java.util.List;

import com.bean.Student;
import com.dao.Studentdao;

public class StudentService {
	Studentdao dao = new Studentdao();
	
	 public String storeTrainer(Student s) {
	        if(dao.storeStudent(s)>0) {
	            return "Student details stored successfully";
	        }else {
	            return "could not store Student details";
	        }
	    }
	 
	 public List<Student> findAllStudents()
	 {
		 return dao.findAllStudent();
	 }

}
