package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.*;
import com.service.*;

/**
 * Servlet implementation class StudentController
 */
public class StudentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		StudentService ts = new StudentService();
		List<Student> stu = ts.findAllStudents();
		HttpSession hs = request.getSession();
		hs.setAttribute("students", stu);
		response.sendRedirect("studentview.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		StudentService ts = new StudentService();
		Student t = new Student();
		t.setSid(Integer.parseInt(request.getParameter("id")));
		t.setSname(request.getParameter("name"));
		t.setAge(Integer.parseInt(request.getParameter("age")));
		HttpSession hs = request.getSession();
		hs.setAttribute("StudentStore", ts.storeTrainer(t));
		RequestDispatcher rd = request.getRequestDispatcher("storestudent.jsp");
		rd.include(request, response);
		
		
	}

}
