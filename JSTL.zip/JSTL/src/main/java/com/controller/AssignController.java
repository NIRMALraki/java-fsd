package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.Clas;
import com.bean.Student;
import com.bean.Subject;
import com.bean.Trainer;
import com.service.ClassService;
import com.service.StudentService;
import com.service.SubjectService;
import com.service.TrainerService;

/**
 * Servlet implementation class AssignController
 */
public class AssignController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AssignController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		ClassService ts = new ClassService();
		SubjectService ss = new SubjectService();
		
		
		
		List<Clas> stu = ts.findAllClass();
		List<Subject> sub = ss.findAllSubject();
		
		
		HttpSession hs = request.getSession();
		hs.setMaxInactiveInterval(300);
		hs.setAttribute("classes", stu);
		hs.setAttribute("subjects",sub);
		response.sendRedirect("AssignSubject.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	
		PrintWriter pw = response.getWriter();
		
		
		pw.println();
		pw.println("class :"+request.getParameter("Classid"));
		pw.println("Subject :"+request.getParameter("subjectid"));
		//pw.println("class :"+request.getParameter("trainerid"));
		
	
	}

}
