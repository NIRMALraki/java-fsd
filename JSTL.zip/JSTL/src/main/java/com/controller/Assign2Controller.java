package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.bean.Clas;
import com.bean.Student;
import com.bean.Subject;
import com.bean.Trainer;
import com.dao.Trainerdao;
import com.service.StudentService;
import com.service.SubjectService;
import com.service.TrainerService;

/**
 * Servlet implementation class Assign2Controller
 */
public class Assign2Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Assign2Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		TrainerService tss = new TrainerService();
		Trainerdao tdao = new Trainerdao();
		SubjectService ss= new SubjectService();
		StudentService sts= new StudentService();
		Session ses = tdao.connection();
		
		ss.assignSubject(Integer.parseInt(request.getParameter("subjectid")),Integer.parseInt(request.getParameter("Classid")));
		

		Clas cla=ses.get(Clas.class,Integer.parseInt(request.getParameter("Classid")));
	
		
		List<Trainer> tra = tss.findAllTrainer();
		List<Student> stud = sts.findAllStudents();
		
		HttpSession hs = request.getSession();
		
		hs.setAttribute("trainers", tra);
		hs.setAttribute("students", stud);
		hs.setAttribute("clsname", cla.getClassname());
		hs.setAttribute("clsid", cla.getClassid());
		
		response.sendRedirect("assign2.jsp");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		HttpSession hs = request.getSession();
		Trainerdao tdao = new Trainerdao();
		PrintWriter pw = response.getWriter();
		Session ses = tdao.connection();
		Transaction tran = ses.beginTransaction();
		int aa=(int) hs.getAttribute("clsid");
		Clas cla=ses.get(Clas.class,aa);
		Student st1 = ses.get(Student.class,Integer.parseInt(request.getParameter("stid")) );
		Trainer tr1= ses.get(Trainer.class,Integer.parseInt(request.getParameter("tid")) );
		//SubjectService ss = new SubjectService();
		cla.getListofstu().add(st1);
		cla.getListoftra().add(tr1);
		
		st1.setCs(cla);
		tr1.setCs(cla);
		
		ses.update(cla);
		ses.update(tr1);
		ses.update(st1);
		tran.commit();
		ses.close();
		
		
//		pw.println("Trainer :"+request.getParameter("tid"));
//		pw.println("Student :"+request.getParameter("stid"));
		pw.println("<a href=\"index.jsp\">Main Page</a");
		
		
		
		
		
		
		
	}

}
