package com.controller;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.Login;
import com.service.LoginService;

/**
 * Servlet implementation class LoginController
 */
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Login l1 = new Login();
		LoginService ls = new LoginService();
		HttpSession  hs = request.getSession();
		RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
		//PrintWriter pw = response.getWriter();
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		l1.setEmail(email);
		l1.setPassword(password);
		
		if(ls.login(l1)<1)
		{
			hs.setAttribute("email", email );
			response.sendRedirect("index.jsp");
		}
		else
		{	
			request.setAttribute("LoginError", "Invalid credentials");
			rd.include(request, response);
		}
	}

}
