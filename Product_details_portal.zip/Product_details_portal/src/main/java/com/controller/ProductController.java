package com.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import com.bean.Products;

/**
 * Servlet implementation class ProductController
 */
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Products p = new Products();
		RequestDispatcher rd= request.getRequestDispatcher("ProductDetails.jsp");
		
		
		p.setId(Integer.parseInt(request.getParameter("id")));
		p.setName(request.getParameter("name"));
		p.setQty(Integer.parseInt(request.getParameter("qty")));
		p.setImage(request.getParameter("image"));
		
		
		List<Products>products;
		products = (List<Products>)request.getAttribute("productsarray");
		if(products==null)
		{
			products= new ArrayList<Products>();
			//products=(List<Products>) s.getAttribute("productsarray");
			System.out.println(products.isEmpty()); 
			products.add(p);
			System.out.println(products.isEmpty()); 
			request.setAttribute("productsarray", products);
		}
		else
		{
			products=(List<Products>) request.getAttribute("productsarray");
			products.add(p);
			request.setAttribute("productsarray", products);
		}
		
		rd.forward(request, response);
	
		
	}

}
