package com;

import java.io.File;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RegisterTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\NR\\Phase-5_workspace\\chromedriver_win32\\chromedriver.exe");
		WebDriver chrome= new ChromeDriver();
		
		chrome.get("http://127.0.0.1:5500/web_application/register.html");
//		WebElement a= chrome.findElement(By.id("register"));
//		a.click();
//		chrome.switchTo().alert().accept();
//		
		System.out.println(chrome.getCurrentUrl());
		
		WebElement uname= chrome.findElement(By.id("username"));
		WebElement pass= chrome.findElement(By.id("password"));
		WebElement email= chrome.findElement(By.id("email"));
		WebElement phno= chrome.findElement(By.id("phno"));
		WebElement register= chrome.findElement(By.id("register"));
		
		email.sendKeys("nirmal@yahoo.com");
		pass.sendKeys("nirmal");
		uname.sendKeys("nirmal");
		phno.sendKeys("9110206098");
		TakesScreenshot ts = (TakesScreenshot)chrome;
	       File scr = ts.getScreenshotAs(OutputType.FILE);
	      // Files.copyFile(scr, new File("/Screenshot/test.png");

		
		register.click();
		Alert alert=chrome.switchTo().alert();
		System.out.println(alert.getText());
		alert.accept();
		
		
		
		

	}

}
