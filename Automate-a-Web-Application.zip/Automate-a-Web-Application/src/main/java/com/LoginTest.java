package com;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginTest {
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\NR\\Phase-5_workspace\\chromedriver_win32\\chromedriver.exe");
		WebDriver chrome= new ChromeDriver();
		chrome.get("http://127.0.0.1:5500/web_application/Login.html");
		
		WebElement uname= chrome.findElement(By.id("username"));
		WebElement pass= chrome.findElement(By.id("password"));
		WebElement login= chrome.findElement(By.id("login"));
		
		
		uname.sendKeys("nirmal@yahoo.com");
		pass.sendKeys("nirmal");
		login.click();
		Alert alert=chrome.switchTo().alert();
		System.out.println(alert.getText());
		alert.accept();
		
		
	}	

}
