package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.transaction.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bean.Feedback;

@Repository
public class Feedbackdao {
	@Autowired
	EntityManagerFactory emf;
	
	public int store(Feedback fd)
	{
		try {
			EntityManager em= emf.createEntityManager();
			EntityTransaction t= em.getTransaction();
			t.begin();
			em.persist(fd);
			t.commit();
			return 0;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 1;
		}
		
		
	}
	

}
