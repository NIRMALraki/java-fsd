package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Feedback;
import com.dao.Feedbackdao;

@Service
public class FeedbackService {
	
	@Autowired
	Feedbackdao da;
	
	public String storeFeed(Feedback fd)
	{
		if(da.store(fd)<1)
		{
			return "stored";
			
		}
		else
		{
			return "unsuccessfull";
		}
	}

}
