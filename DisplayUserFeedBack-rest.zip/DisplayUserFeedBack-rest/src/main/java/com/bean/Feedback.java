package com.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Component
@Entity
@Table(name="feedback")
public class Feedback {
	@Id
	private String email;
	private String feedback;
//	public Feedback() {
//		super();
//	}
//	public Feedback(String email, String feedback) {
//		super();
//		this.email = email;
//		this.feedback = feedback;
//	}
//	@Override
//	public String toString() {
//		return "Feedback [email=" + email + ", feedback=" + feedback + "]";
//	}
//	public String getEmail() {
//		return email;
//	}
//	public void setEmail(String email) {
//		this.email = email;
//	}
//	public String getFeedback() {
//		return feedback;
//	}
//	public void setFeedback(String feedback) {
//		this.feedback = feedback;
//	}

}
