package assistedphase3;

public class DoublyLinkedList {
	
	Node head; 
	class Node 
	{ 
	        		int data; 
	        		Node pre; 
	        		Node next; 
	Node(int d) 
	{ 
		data = d; 
	} 
	    	}
	public void push(int newData) 
	    { 
				Node newNode = new Node(newData); 
				newNode.next = head; 
	        	newNode.pre = null; 
	        	if (head != null) 
	        	{
	            		head.pre = newNode; 
	        	}
	        	head = newNode; 
	   
	    	} 
	public void InsertAfter(Node preNode, int newData) 
	    	{ 
					if (preNode == null) 
					{ 
	            			System.out.println("The previous node is null "); 
	            			return; 
	        		} 	
					Node newNode = new Node(newData); 
					newNode.next = preNode.next; 
					preNode.next = newNode; 
					newNode.pre = preNode; 
					if (newNode.next != null) 
					{
	            			newNode.next.pre = newNode; 
					}
	    	} 
	    	void append(int newData) 
	    	{ 
	    		Node newnode = new Node(newData); 
	    		Node last = head; 
	    		newnode.next = null;
	    		if (head == null) 
	    		{ 
	            	newnode.pre = null; 
	            	head = newnode; 
	            	return; 
	        	} 
	    		while (last.next != null) { 
	            			last = last.next;
	    		}
	    			last.next = newnode; 
	    			newnode.pre = last; 
	    		} 
	    	
	public void printlist(Node node) 
	    		{ 
	        		Node last = null; 
	        		System.out.println("Traverse front"); 
	        		while (node != null) 
	        		{ 
	            			System.out.print(node.data + " "); 
	            			last = node; 
	            			node = node.next; 
	        		} 
	        		System.out.println(); 
	        		System.out.println("Traverse back"); 
	        		while (last != null) 
	        		{ 
	            			System.out.print(last.data + " "); 
	            			last = last.pre; 
	        		} 
	    	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DoublyLinkedList a = new DoublyLinkedList();
				a.append(4); 
				a.push(5);
				a.append(89);
				a.push(0);  
				a.append(86);
				a.InsertAfter(a.head.next, 6); 
				a.printlist(a.head); 

	}

}
