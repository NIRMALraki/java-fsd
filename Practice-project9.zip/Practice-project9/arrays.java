package Assisted_project;

public class arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] st = new String[4];
		st[0] = "one";
		st[1] = "two";
		st[2] = "three";
		st[3] = "four";
		//st[4] = "five";
		
		for (String string : st) {
			System.out.println(string);
		}
		
		int[][][] mul = {{{1,2,3},{1,2,3}},{{1,2,3}}}; 
	
		System.out.println(mul.length);
		System.out.println(mul[0].length);
		System.out.println(mul[0][0].length);
	}

}
