package assistedphase3;

public class ArrayRotation {
	public void rotate(int[] n, int r) {
		if(r > n.length) 
   			r=r%n.length;
		int result[] = new int[n.length];
		for(int i=0; i < r; i++){
    			result[i] = n[n.length-r+i];
		}
		int j=0;
		for(int i=r; i<n.length; i++){
    			result[i] = n[j];
    			j++;
		}
		System.arraycopy( result, 0, n, 0, n.length );
}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayRotation ar= new ArrayRotation();
		int[] arr= {10,9,8,7,6,5,4,3,2,1};
		ar.rotate(arr, 8);
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}

}
