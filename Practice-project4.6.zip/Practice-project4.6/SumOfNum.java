package assistedphase3;

public class SumOfNum {
	static void sum(int[] arr,int l,int r)
	{
		int res=0;
		for (int i = l; i < r; i++) {
			
			
			res+=arr[i];
			
		}
		System.out.println(res);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr= {5,45,53,4,6,3,2,43,6,7};
		
		sum(arr,0,5);
		sum(arr,6,8);
		
	}

}
