package practice_3_14;

public class Clsobj {
	String State,Capital;
	
	public Clsobj(String state, String capital) {
		
		this.State = state;
		this.Capital = capital;
	}
	

	public String getState() {
		return State;
	}


	public void setState(String state) {
		State = state;
	}


	public String getCapital() {
		return Capital;
	}


	public void setCapital(String capital) {
		Capital = capital;
	}


	@Override
	public String toString() {
		return "Clsobj [State=" + State + ", Capital=" + Capital + "]";
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Clsobj one = new Clsobj("Karnataka","bengaluru");
		System.out.println(one.toString());
		
		Clsobj two = new Clsobj("Tamil Nadu","Chennai");
		System.out.println(two.toString());

	}

}
