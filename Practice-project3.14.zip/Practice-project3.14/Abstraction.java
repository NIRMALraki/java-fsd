package practice_3_14;

public class Abstraction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WhatsApp v1= new Version1();
		v1.chat();
		v1.videoCall();
		v1.voiceCall();
		
		WhatsApp v2= new Version2();
		v2.chat();
		v2.videoCall();
		v2.voiceCall();
		
		WhatsApp v3= new Version3();
		v3.chat();
		v3.videoCall();
		v3.voiceCall();
		
	}

}

abstract class WhatsApp{
	
	abstract void chat();
	abstract void voiceCall();
	abstract void videoCall();

}

class Version1 extends WhatsApp
{

	@Override
	void chat() {
		System.out.println("Chat activity implemeted in version1");
		
	}

	@Override
	void voiceCall() {
		// TODO Auto-generated method stub
		System.out.println("not implemented");
	}

	@Override
	void videoCall() {
		// TODO Auto-generated method stub
		System.out.println("not impletented");
		
	}
	
}
class Version2 extends WhatsApp{

	@Override
	void chat() {
		System.out.println("Chat activity implemeted in version1");
		
	}

	@Override
	void voiceCall() {
		// TODO Auto-generated method stub
		System.out.println("voice call implemented in version2");
	}

	@Override
	void videoCall() {
		// TODO Auto-generated method stub
		System.out.println("not impletented");
		
	}
	
}
class Version3 extends WhatsApp
{
	@Override
	void chat() {
		System.out.println("Chat activity implemeted in version1");
		
	}

	@Override
	void voiceCall() {
		// TODO Auto-generated method stub
		System.out.println("voice call implemented in version2");
	}

	@Override
	void videoCall() {
		// TODO Auto-generated method stub
		System.out.println("Video call impletented in version3");
		
	}
}
