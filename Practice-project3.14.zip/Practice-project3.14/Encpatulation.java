package practice_3_14;

public class Encpatulation {
	
	String Name;
	private int phno,aadharno,accountno;
	

	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	public int getPhno() {
		return phno;
	}


	public void setPhno(int phno) {
		this.phno = phno;
	}


	public int getAadharno() {
		return aadharno;
	}


	public void setAadharno(int aadharno) {
		this.aadharno = aadharno;
	}


	public int getAccountno() {
		return accountno;
	}


	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Encpatulation e= new Encpatulation();
		e.setName("nirmal");
		e.setAadharno(98237489);
		e.setAccountno(826873926);
		e.setPhno(89789437);
		System.out.println(e.getAadharno());
		System.out.println(e.getAccountno());
		System.out.println(e.getPhno());
		System.out.println(e.getName());
		
		

	}

}
