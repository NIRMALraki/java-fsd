package practice_3_14;

public class Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		Salary s= new Manager();
		s.getSalary();
		Salary s1= new Employee();
		s1.getSalary();
	}

}

class Manager extends Salary 
{
	void getSalary()
	{
		int sal=100000;
		System.out.println("the salary is "+ sal);
	}
}

class Salary
{
	void getSalary()
	{
		int sal=0;
		System.out.println("the salary is "+ sal);
	}
}
class Employee extends Salary{
	void getSalary()
	{
		int sal=50000;
		System.out.println("the salary is "+ sal);
	}
}