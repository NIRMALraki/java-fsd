package practice_3_14;

public class Poly {
	
	
	void login(String name,String email)
	{
		System.out.println("name : "+name);
		System.out.println("email : "+email);
	}
	
	void login(String name,String email,int phono)
	{
		System.out.println("name :"+name);
		System.out.println("email :"+email);
		System.out.println("phno :"+phono);
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Poly p1= new Poly();
		p1.login("nimral", "nirmal.yahoo.com");
		p1.login("madhu", "madhu@gmail.com",789951678);
	}

}
