package Filehandling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class FileHandle {
	
	File f;
	FileWriter writer;
	Scanner sc;
	
	void create(String filename) throws IOException
	{
		f = new File(filename);
		if(!f.exists())
		{
			f.createNewFile();
			System.out.println("file Created");
		}
		else
		{
			System.out.println("file Already exist");
		}
		
	}
	
	void write(String filename,String s)
	{
		f = new File(filename);
		if(f.exists())
		{
			try {
				s+="\r\n";
				writer= new FileWriter(f);
				writer.write(s.toCharArray());
				writer.close();
				System.out.println("write Successfull");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			System.out.println("file not found");
		}
		
		
		
	}
	
	void read(String fi)
	{
		String re="";
		f = new File(fi);
		if(f.exists())
		{
			try {
				sc= new Scanner(f);
				while(sc.hasNextLine())
				{
					re+=sc.nextLine();
				}
				System.out.println(re);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		else
		{
			System.out.println("file not found");
		}
	}
	
	void append(String fi,String st)
	{
		f = new File(fi);
		if(f.exists())
		{
			try {
				st+="\r\n";
				writer = new FileWriter(f,true);
				writer.write(st);
				writer.close();
				System.out.println("append successfull");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		else
		{
			System.out.println("file not found");
		}
	}
	
	void delete(String fi)
	{
		f = new File(fi);
		f.delete();
		System.out.println("deleted");
	}
	

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		int opt;
		boolean flag=true;
		FileHandle f1= new FileHandle();
		Scanner sc = new Scanner(System.in);
		String fn,st;
		BufferedReader b= new BufferedReader(new InputStreamReader(System.in));
		
		while(flag)
		{
			System.out.println("********File Handling********");
			System.out.println("1.Create File\n2.Write File\n3.Read File\n4.Append File\n5.delete\n6.exit");
			opt= sc.nextInt();
			System.out.println(opt);
			switch(opt)
			{
				case 1:
					System.out.println("enter the file name");
					fn= sc.next();
					f1.create(fn);
					break;
				case 2:
					System.out.println("enter the file name and text to write");
					fn=b.readLine();
					System.out.println("enter the text to be written");
					st=b.readLine();
					
					f1.write(fn,st);
					break;
				case 3:
					System.out.println("enter the file name and text to read");
					fn=b.readLine();
					f1.read(fn);
					break;
				case 4:
					System.out.println("enter the file name and text to append");
					fn=b.readLine();
					System.out.println("enter the text to append");
					st=b.readLine();
					f1.append(fn,st);
					break;
				case 5:
					System.out.println("enter the file name to delete");
					fn=b.readLine();
					f1.delete(fn);
					break;
				case 6:
					flag=false;
					break;
					
				default:
					System.out.println("invalid Option");
					
			}
			
			
		}
		
		
		

	}

}
