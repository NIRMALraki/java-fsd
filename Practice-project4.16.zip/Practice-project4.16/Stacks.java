package assistedphase3;

import java.util.Iterator;
import java.util.Stack;

public class Stacks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack stk = new Stack();  
		stk.push("BMW");  
		stk.push("Audi");  
		stk.push("Ferrari");  
		stk.push("Bugatti");  
		stk.push("Jaguar");  
		Iterator iterator = stk.iterator();  
		while(iterator.hasNext())  
		{  
		Object values = iterator.next();  
		System.out.println(values);   
		}     
		
		stk.pop();
		System.out.println("after pop");
		for (Object object : stk) {
			System.out.println(object);
		}

	}

}
