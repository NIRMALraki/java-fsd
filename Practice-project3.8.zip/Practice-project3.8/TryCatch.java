package Assisted_project;

public class TryCatch {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s= new String();
		try
		{
			for (int i = 0; i < 3; i++) {
				
				System.out.println(s.charAt(i));
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			System.out.println("length is"+s.length()+" but iterating for 3 times");
		}
		
	}

}
