import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class FileExplorer {
	static File f;
	FileWriter writer;
	static final String DIR="C:\\Users\\NR\\OneDrive\\Desktop\\sample folder";
	
	static void create(String filename) throws IOException
	{
		f = new File(DIR+"\\"+filename);
		System.out.println(f.getPath());
		if(!f.exists())
		{
			f.createNewFile();
			System.out.println("file Created");
		}
		else
		{
			System.out.println("file Already exist");
		}
		
	}
	
	static void delete(String fi)
	{
		f = new File(DIR+"\\"+fi);
		if(f.exists())
		{
			f.delete();
			System.out.println("deleted");
		}
		else
		{
			System.out.println("File Not Found !.");
		}
		
	}
	
	static void display()
	{
		f= new File(DIR);
		List<String> files =Arrays.asList(f.list());
		Collections.sort(files);
		for(String names : files)
		{
			System.out.println(names+" | ");
		}
		
	}
	
	static void search(String filename)
	{
		f= new File(DIR+"\\"+filename);
		if(f.exists())
		{
			System.out.println("File is present in the directory1");
			System.out.println("Path of the file : "+f.getAbsolutePath());
		}
		else
		{
			System.out.println("file not found !");
		}
		
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		boolean flag=true,flag2=true;
		int opt=0;
		
		System.out.println("******* FILE EXPLORER ********");
		System.out.println("\nDeveloper Details:\nName:Nirmal Kumar");
		
		while(flag)
		{
			System.out.println();
			System.out.println("Please select any one of the options for respective operation ");
			System.out.println("1.Display files in the directory\n2.Perform file operations\n3.exit");
			opt= sc.nextInt();
			switch(opt)
			{
			case 1:
				System.out.println("Files present in the current directory");
				display();
				break;
			case 2:
				while(flag2)
				{
					System.out.println("\n********File operations*******");
					System.out.println("1.Add a file to the directory\n2.Delete a file\n3.Search the file\n4.Switch to main menu");
					opt=sc.nextInt();
					switch(opt)
					{
					case 1:
						System.out.println("Enter the name of the file to add");
						create(sc.next());
						break;
					case 2:
						display();
						System.out.println("Enter the file name from above list to delete file (Case sensitive)");
						delete(sc.next());
						break;
					case 3:
						//display();
						System.out.println("Enter the file name to Search (Case sensitive)");
						search(sc.next());
						break;
					case 4:
						flag2=false;
						break;
					default:
						System.out.println("invalid option entered");
						
					}
					
				}
				flag2=true;
				break;
			case 3:
				System.out.println(" Thank You ");
				flag=false;
				sc.close();
				break;
			
			default:
				System.out.println("invalid option entered");
				
				
			}
			
		}
		
		
	}

}
