package Assisted_project;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileOpration1 {
	
	

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		final String FILENAME="text1.txt"; 
		//create
		File file = new File(FILENAME);
		if(file.createNewFile()) System.out.println("file created");
		
		
		//write
		FileWriter write = new FileWriter(FILENAME);
		write.write("written from program");
		write.close();
		
		
		//read
		System.out.println("reading");
		Scanner content= new Scanner(file);
		while(content.hasNextLine())
		{
			System.out.println(content.nextLine());
		}
	
		
		//update
		content= new Scanner(file);
		String data="";
		String Update="updating file at the end";
		System.out.println("updating");
		while(content.hasNextLine())
		{
			data+= content.nextLine();	
		}
	
		write = new FileWriter(FILENAME);
		write.write(data+" "+Update);
		write.close();
		
		
		
		//display
		System.out.println("display");
		content= new Scanner(file);
		while(content.hasNext())
		{
			System.out.println(content.nextLine());
		}
		
		//delete
		
//		if(file.delete()) {
//			System.out.println("deleted");
//		}
//		else
//		{
//			System.out.println(file.delete());
//		}
		
		

	}

}
