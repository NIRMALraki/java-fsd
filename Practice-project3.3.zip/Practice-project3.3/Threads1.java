package Assisted_project;

public class Threads1 extends Thread {
		@Override
		public void run() {
			int num=0;
			System.out.println("thread started running");
			while(num<=10)
			{
			super.run();
			System.out.println(num);
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			num++;
			}
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Threads1 t1 = new Threads1();
		t1.start();
		

	}

}
