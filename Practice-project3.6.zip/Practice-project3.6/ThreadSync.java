package Assisted_project;

public class ThreadSync {
	
	static Object obj1 = new Object();
	

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		Thread.sleep(1000);
		System.out.println("the thread "+Thread.currentThread().getName()+" is sleep in for 1 second");
		synchronized(obj1)
		{
			obj1.wait(1000);
			System.out.println("object" + obj1 +" executed after 1 sec");
		}
        

		

	}

}
