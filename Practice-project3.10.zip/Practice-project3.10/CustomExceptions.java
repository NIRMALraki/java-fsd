package Assisted_project;

public class CustomExceptions {
		static int  a;
	public static void main(String[] args) throws Custom {
		// TODO Auto-generated method stub
		
		
		CustomExceptions c=null;
		try
		{
			if (c==null)
			throw new Custom("the object is null");
		}
		finally
		{
			System.out.println("the local variable is intialized to null ");
		}
	}

}
class Custom extends Throwable
{
	Custom(String msg)
	{
		super(msg);
	}
}
