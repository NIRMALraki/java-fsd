package Assisted_project;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Vector;

public class collections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("*****collections*****");
		System.out.println("        Arraylist        ");
		
		ArrayList<String> Language = new ArrayList<>(); 
		Language.add("Java");
		Language.add("Python");
		Language.add("c++");
		System.out.println(Language.contains("python"));
		System.out.println(Language.get(1));
		System.out.println(Language.isEmpty());
		System.out.println("Elements in array");
		System.out.println(Language.toString());
		for (String string : Language) 
		{
			System.out.println(string);
		}
		System.out.println("        Linkedlist        ");
		
		List<Integer> li= new LinkedList<>();
		li.add(20);
		li.add(4);
		li.add(983);
		li.add(43);
		li.add(2, 978);
		System.out.println(li.lastIndexOf(li));
		System.out.println(li.size());
		System.out.println(li.get(2));
		li.remove(1);
		System.out.println(li.toString());
		
		System.out.println("        Hashset        ");
		
		Set<Float> se = new HashSet<>();
		
		se.add(68.435f);
		se.add(43.54f);
		se.add(34.53f);
		System.out.println(se.size());
		System.out.println(se.toString());
	
		System.out.println("        vector        ");
		Vector<String> ve = new Vector<>();
		ve.insertElementAt("first", 0);
		ve.add("second");
		ve.add("third");
		System.out.println(ve.lastElement());
		ve.add(0, null);
		Iterator<String> it =ve.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		System.out.println("        linkedHashset        ");
		
		LinkedHashSet<Integer> lhs=new LinkedHashSet<Integer>();
		lhs.add(3);
		lhs.add(6);
		lhs.add(78);
		System.out.println(lhs.isEmpty());
		System.out.println(lhs.toString());
		
		
	}

}
